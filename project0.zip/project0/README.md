# Project 0
In the index tab is copied and pasted hello world page from the project objective.
I used my knowledge of creating a table and made a table showing the affects of COVID-19.
I created an image html of a picture of my favorite animal. Inserted fun facts and added a bootstrap with a hyperlink to website that I got fun facts from.
My 4th and final html includes a list of my personal active top 5 NBA players. 

Web Programming with Python and JavaScript
